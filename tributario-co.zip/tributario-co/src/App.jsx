import { useState, useRef, useCallback } from "react";

// ── PALETA ─────────────────────────────────────────────────
const C = {
  bg:"#06090F", surface:"#0D1117", card:"#111820", cardHover:"#161F2C",
  border:"#1C2A3A", borderHover:"#2A3F58",
  accent:"#00C9A7", accentDim:"#00C9A712", accentGlow:"#00C9A730",
  gold:"#F0A500", goldDim:"#F0A50015",
  text:"#E2EAF4", muted:"#506070", sub:"#8A9BB0",
  danger:"#FF4D6A", dangerDim:"#FF4D6A15",
  blue:"#3B9BF5", blueDim:"#3B9BF512",
  purple:"#9B72FF", purpleDim:"#9B72FF15",
  green:"#22C55E", greenDim:"#22C55E15",
};

const UVT = 47065;
const fmt  = n => Math.round(parseInt(n||0)).toLocaleString("es-CO");
const now  = () => new Date().toLocaleDateString("es-CO",{day:"2-digit",month:"short",year:"numeric"});

const calcImp = base => {
  const u = base/UVT;
  if(u>1090) return Math.round(((u-1090)*0.39+788)*UVT);
  if(u>650)  return Math.round(((u-650)*0.33+642)*UVT);
  if(u>360)  return Math.round(((u-360)*0.28+116)*UVT);
  if(u>195)  return Math.round((u-195)*0.19*UVT);
  return 0;
};

// ── ESTADO GLOBAL (simula BD) ───────────────────────────────
const CLIENTES_DEMO = [
  { id:1, cedula:"12.345.678", nombre:"Carlos Enrique Mora", tipo:"Empleado (obligado)", estado:"pendiente_revision", fecha:"02 Jun 2025",
    datos:{ ingresos_laborales:82000000, honorarios:0, pension:0, dividendos:0, otros_ingresos:0, retenciones:6500000, patrimonio_inmuebles:150000000, patrimonio_vehiculos:35000000, saldo_bancario:8000000, cdt_inversiones:0, deuda_hipoteca:45000000, otras_deudas:5000000, medicina_prepagada:3200000, intereses_vivienda:4800000, dependientes:2 },
    comentario_contador:"", docs:["Certificado_ingresos.jpg","Extracto_bancario.jpg"] },
  { id:2, cedula:"43.876.543", nombre:"María Fernanda Ospina", tipo:"Trabajador independiente", estado:"aprobado", fecha:"30 May 2025",
    datos:{ ingresos_laborales:0, honorarios:95000000, pension:0, dividendos:0, otros_ingresos:0, retenciones:9500000, patrimonio_inmuebles:0, patrimonio_vehiculos:0, saldo_bancario:12000000, cdt_inversiones:20000000, deuda_hipoteca:0, otras_deudas:2000000, medicina_prepagada:4800000, intereses_vivienda:0, dependientes:0 },
    comentario_contador:"Todo correcto. Excelente organización.", docs:["Extractos_honorarios.pdf"] },
  { id:3, cedula:"98.765.432", nombre:"Jorge Iván Salcedo", tipo:"Pensionado", estado:"en_proceso", fecha:"04 Jun 2025",
    datos:null, docs:[] },
  { id:4, cedula:"71.234.567", nombre:"Luz Marina Cárdenas", tipo:"Empleado (obligado)", estado:"documentos_pendientes", fecha:"03 Jun 2025",
    datos:null, docs:["Predial_2024.jpg"] },
];

const STATUS = {
  documentos_pendientes: { label:"Docs. pendientes", color:C.muted,   icon:"📁" },
  en_proceso:            { label:"En proceso",       color:C.gold,    icon:"⚙️" },
  pendiente_revision:    { label:"Pendiente revisión",color:C.blue,   icon:"👁️" },
  aprobado:              { label:"Aprobado",          color:C.accent,  icon:"✅" },
  presentado:            { label:"Presentado DIAN",   color:C.green,   icon:"🏛️" },
};

// ── COMPONENTES BASE ───────────────────────────────────────
const Tag = ({color,children,small})=>(
  <span style={{display:"inline-flex",alignItems:"center",gap:4,padding:small?"2px 8px":"3px 10px",borderRadius:20,fontSize:small?9:11,fontWeight:800,letterSpacing:0.6,textTransform:"uppercase",background:color+"18",color,border:`1px solid ${color}28`}}>{children}</span>
);
const Btn = ({children,onClick,variant="primary",size="md",disabled,full})=>{
  const base={padding:size==="sm"?"6px 14px":size==="lg"?"14px 28px":"11px 22px",borderRadius:9,fontWeight:700,fontSize:size==="sm"?11:14,cursor:disabled?"not-allowed":"pointer",border:"none",transition:"all 0.2s",opacity:disabled?0.5:1,width:full?"100%":"auto"};
  const v={primary:{background:C.accent,color:"#000"},ghost:{background:"transparent",color:C.sub,border:`1px solid ${C.border}`},gold:{background:C.goldDim,color:C.gold,border:`1px solid ${C.gold}33`},blue:{background:C.blueDim,color:C.blue,border:`1px solid ${C.blue}33`},danger:{background:C.dangerDim,color:C.danger,border:`1px solid ${C.danger}33`},green:{background:C.greenDim,color:C.green,border:`1px solid ${C.green}33`}};
  return <button style={{...base,...v[variant]}} onClick={onClick} disabled={disabled}>{children}</button>;
};
const Campo = ({label,value,onChange,type="text",placeholder,hint,prefix,readOnly})=>(
  <div style={{marginBottom:14}}>
    <label style={{display:"block",fontSize:10,fontWeight:700,color:C.muted,letterSpacing:1.2,textTransform:"uppercase",marginBottom:6}}>{label}</label>
    <div style={{position:"relative"}}>
      {prefix&&<span style={{position:"absolute",left:11,top:"50%",transform:"translateY(-50%)",color:C.muted,fontSize:12}}>{prefix}</span>}
      <input type={type} value={value} onChange={e=>onChange?.(e.target.value)} placeholder={placeholder} readOnly={readOnly}
        style={{width:"100%",padding:prefix?"10px 12px 10px 26px":"10px 12px",background:readOnly?C.bg:C.surface,border:`1px solid ${C.border}`,borderRadius:7,color:readOnly?C.muted:C.text,fontSize:13,outline:"none",boxSizing:"border-box",cursor:readOnly?"default":"text"}}
        onFocus={e=>{if(!readOnly)e.target.style.borderColor=C.accent;}} onBlur={e=>e.target.style.borderColor=C.border} />
    </div>
    {hint&&<div style={{fontSize:10,color:C.muted,marginTop:4}}>{hint}</div>}
  </div>
);

// ── TARJETA DE CLIENTE ─────────────────────────────────────
const TarjetaCliente = ({c, onAbrir, rol})=>{
  const st = STATUS[c.estado];
  return(
    <div onClick={()=>onAbrir(c)} style={{background:C.card,border:`1px solid ${c.estado==="pendiente_revision"&&rol==="contador"?C.blue+"55":C.border}`,borderRadius:13,padding:"18px 20px",cursor:"pointer",transition:"all 0.18s",position:"relative",overflow:"hidden"}}
      onMouseEnter={e=>e.currentTarget.style.borderColor=C.borderHover} onMouseLeave={e=>e.currentTarget.style.borderColor=c.estado==="pendiente_revision"&&rol==="contador"?C.blue+"55":C.border}>
      {c.estado==="pendiente_revision"&&rol==="contador"&&(
        <div style={{position:"absolute",top:0,right:0,background:C.blue,color:"#fff",fontSize:9,fontWeight:800,padding:"3px 10px",borderRadius:"0 12px 0 8px",letterSpacing:1}}>REVISAR</div>
      )}
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:10}}>
        <div>
          <div style={{fontSize:15,fontWeight:800,color:C.text,marginBottom:3}}>{c.nombre}</div>
          <div style={{fontSize:11,color:C.muted,fontFamily:"monospace"}}>C.C. {c.cedula}</div>
        </div>
        <Tag color={st.color}>{st.icon} {st.label}</Tag>
      </div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <Tag color={C.purple} small>{c.tipo}</Tag>
        <div style={{display:"flex",alignItems:"center",gap:8}}>
          {c.docs?.length>0&&<span style={{fontSize:11,color:C.muted}}>📎 {c.docs.length} docs</span>}
          <span style={{fontSize:11,color:C.muted}}>{c.fecha}</span>
        </div>
      </div>
      {c.datos&&(
        <div style={{marginTop:12,padding:"10px 12px",background:C.surface,borderRadius:8,display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8}}>
          {[
            {l:"Ingresos",v:`$${fmt([c.datos.ingresos_laborales,c.datos.honorarios,c.datos.pension].reduce((a,b)=>a+b,0))}`,col:C.accent},
            {l:"Impuesto",v:`$${fmt(calcImp([c.datos.ingresos_laborales,c.datos.honorarios,c.datos.pension,c.datos.dividendos,c.datos.otros_ingresos].reduce((a,b)=>a+b,0)))}`,col:C.gold},
            {l:"Saldo",v:(()=>{const ing=[c.datos.ingresos_laborales,c.datos.honorarios,c.datos.pension,c.datos.dividendos,c.datos.otros_ingresos].reduce((a,b)=>a+b,0);const imp=calcImp(ing);const sal=imp-c.datos.retenciones;return sal>0?`-$${fmt(sal)}`:`+$${fmt(Math.abs(sal))}`;})(),col:(()=>{const ing=[c.datos.ingresos_laborales,c.datos.honorarios,c.datos.pension,c.datos.dividendos,c.datos.otros_ingresos].reduce((a,b)=>a+b,0);const imp=calcImp(ing);return imp-c.datos.retenciones>0?C.danger:C.accent;})()},
          ].map(x=>(
            <div key={x.l}>
              <div style={{fontSize:9,color:C.muted,fontWeight:700,textTransform:"uppercase",letterSpacing:0.8,marginBottom:3}}>{x.l}</div>
              <div style={{fontSize:12,fontWeight:800,color:x.col}}>{x.v}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

// ── VISTA ASISTENTE: CARGA DE DOCS ─────────────────────────
function SubirDocs({cliente, onVolver, onGuardar}){
  const [fotos, setFotos] = useState(cliente.docs?.map(n=>({name:n,preview:null}))||[]);
  const [analizando, setAnalizando] = useState(false);
  const [log, setLog] = useState([]);
  const [datos, setDatos] = useState(cliente.datos||null);
  const [editando, setEditando] = useState(false);
  const inputRef = useRef();
  const iniciado = useRef(false);
  const addLog = (m,t="ok")=>setLog(p=>[...p,{m,t}]);

  const agregar = files=>{
    const nuevas = Array.from(files).filter(f=>f.type.startsWith("image/")||f.type==="application/pdf").map(f=>({name:f.name,file:f,preview:f.type.startsWith("image/")?URL.createObjectURL(f):null}));
    setFotos(p=>[...p,...nuevas]);
  };

  const toB64 = f=>new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(r.result.split(",")[1]);r.onerror=rej;r.readAsDataURL(f);});

  const analizar = async()=>{
    const nuevas = fotos.filter(f=>f.file);
    if(!nuevas.length){setEditando(true);return;}
    setAnalizando(true); setLog([]); iniciado.current=false;
    addLog("Preparando imágenes de WhatsApp...");
    const parts=[];
    for(const f of nuevas){
      addLog(`Leyendo: ${f.name}`);
      const b64=await toB64(f.file);
      const mt=f.file.type==="application/pdf"?"application/pdf":f.file.type;
      if(f.file.type==="application/pdf") parts.push({type:"document",source:{type:"base64",media_type:mt,data:b64},title:f.name});
      else parts.push({type:"image",source:{type:"base64",media_type:mt,data:b64}});
      parts.push({type:"text",text:`Imagen/documento anterior pertenece al cliente: ${cliente.nombre}, CC ${cliente.cedula}`});
    }
    parts.push({type:"text",text:`Eres experto tributario colombiano. Extrae datos para declaración de renta F-210 año gravable 2024 de ${cliente.nombre} CC ${cliente.cedula}.
Responde SOLO con JSON sin backticks:
{"ingresos_laborales":0,"honorarios":0,"pension":0,"dividendos":0,"otros_ingresos":0,"retenciones":0,"patrimonio_inmuebles":0,"patrimonio_vehiculos":0,"saldo_bancario":0,"cdt_inversiones":0,"deuda_hipoteca":0,"otras_deudas":0,"medicina_prepagada":0,"intereses_vivienda":0,"dependientes":0,"notas":""}
Valores en pesos colombianos enteros. 0 si no aparece. En notas: alertas o datos incompletos.`});
    addLog("Enviando a Claude para análisis...");
    try{
      const res=await fetch("/api/analizar",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:1000,messages:[{role:"user",content:parts}]})});
      const data=await res.json();
      const txt=data.content?.map(b=>b.text||"").join("").trim().replace(/```json|```/g,"").trim();
      const parsed=JSON.parse(txt);
      addLog("✅ Extracción completada");
      setDatos(parsed); setAnalizando(false); setEditando(true);
    }catch{
      addLog("Error — continúa editando manualmente","error");
      setAnalizando(false); setEditando(true);
    }
  };

  const d=datos||{};
  const upd=(k,v)=>setDatos(p=>({...p,[k]:v}));
  const totalIng=[d.ingresos_laborales,d.honorarios,d.pension,d.dividendos,d.otros_ingresos].reduce((a,b)=>a+(parseInt(b)||0),0);
  const impuesto=calcImp(totalIng);
  const saldo=impuesto-(parseInt(d.retenciones)||0);

  return(
    <div>
      {/* Header */}
      <div style={{display:"flex",alignItems:"center",gap:14,marginBottom:28}}>
        <button onClick={onVolver} style={{background:C.surface,border:`1px solid ${C.border}`,borderRadius:8,padding:"8px 14px",color:C.sub,cursor:"pointer",fontSize:13,fontWeight:700}}>← Volver</button>
        <div>
          <div style={{fontSize:20,fontWeight:900,color:C.text}}>{cliente.nombre}</div>
          <div style={{fontSize:12,color:C.muted}}>C.C. {cliente.cedula} · {cliente.tipo}</div>
        </div>
      </div>

      {!editando&&(
        <>
          {/* Zona de carga WhatsApp */}
          <div style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:14,padding:"24px",marginBottom:20}}>
            <div style={{fontSize:15,fontWeight:800,color:C.text,marginBottom:6}}>📱 Documentos recibidos por WhatsApp</div>
            <div style={{fontSize:12,color:C.muted,marginBottom:18}}>Sube las fotos o capturas que te envió el cliente. La IA los lee automáticamente.</div>

            {/* Drop zone */}
            <div onClick={()=>inputRef.current?.click()} style={{border:`2px dashed ${C.border}`,borderRadius:12,padding:"32px",textAlign:"center",cursor:"pointer",background:C.surface,marginBottom:18,transition:"all 0.2s"}}
              onDragOver={e=>{e.preventDefault();e.currentTarget.style.borderColor=C.accent;e.currentTarget.style.background=C.accentDim;}}
              onDragLeave={e=>{e.currentTarget.style.borderColor=C.border;e.currentTarget.style.background=C.surface;}}
              onDrop={e=>{e.preventDefault();e.currentTarget.style.borderColor=C.border;e.currentTarget.style.background=C.surface;agregar(e.dataTransfer.files);}}>
              <div style={{fontSize:32,marginBottom:8}}>📸</div>
              <div style={{fontSize:14,fontWeight:700,color:C.sub,marginBottom:4}}>Toca aquí o arrastra las fotos</div>
              <div style={{fontSize:12,color:C.muted}}>JPG · PNG · PDF · Fotos de WhatsApp</div>
              <input ref={inputRef} type="file" multiple accept="image/*,.pdf" style={{display:"none"}} onChange={e=>agregar(e.target.files)}/>
            </div>

            {/* Miniaturas */}
            {fotos.length>0&&(
              <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(100px,1fr))",gap:10,marginBottom:16}}>
                {fotos.map((f,i)=>(
                  <div key={i} style={{position:"relative",borderRadius:9,overflow:"hidden",background:C.surface,border:`1px solid ${C.border}`,aspectRatio:"1"}}>
                    {f.preview?(
                      <img src={f.preview} alt={f.name} style={{width:"100%",height:"100%",objectFit:"cover"}}/>
                    ):(
                      <div style={{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"100%",padding:8}}>
                        <div style={{fontSize:24}}>📄</div>
                        <div style={{fontSize:9,color:C.muted,textAlign:"center",marginTop:4,wordBreak:"break-all",lineHeight:1.2}}>{f.name}</div>
                      </div>
                    )}
                    <button onClick={e=>{e.stopPropagation();setFotos(p=>p.filter((_,j)=>j!==i));}} style={{position:"absolute",top:4,right:4,background:"rgba(0,0,0,0.7)",border:"none",color:"#fff",borderRadius:"50%",width:20,height:20,fontSize:10,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center"}}>✕</button>
                  </div>
                ))}
              </div>
            )}

            {/* Log de análisis */}
            {log.length>0&&(
              <div style={{background:C.bg,borderRadius:8,padding:"12px 14px",marginBottom:14,fontFamily:"monospace"}}>
                {log.map((l,i)=><div key={i} style={{fontSize:12,color:l.t==="error"?C.danger:C.sub,marginBottom:4,display:"flex",gap:8}}><span style={{color:l.t==="error"?C.danger:C.accent}}>{l.t==="error"?"✗":"✓"}</span>{l.m}</div>)}
                {analizando&&<div style={{display:"flex",gap:5,marginTop:8}}>{[0,1,2].map(i=><div key={i} style={{width:5,height:5,borderRadius:"50%",background:C.accent,animation:`p 1.2s ${i*0.2}s infinite`}}/>)}</div>}
              </div>
            )}

            <div style={{display:"flex",gap:12}}>
              <Btn onClick={analizar} disabled={analizando} variant="primary">
                {analizando?"Analizando...":fotos.filter(f=>f.file).length>0?`🤖 Analizar ${fotos.filter(f=>f.file).length} foto(s) con IA`:"Continuar sin fotos →"}
              </Btn>
              {fotos.filter(f=>f.file).length===0&&datos&&<Btn variant="gold" onClick={()=>setEditando(true)}>Ver datos guardados →</Btn>}
            </div>
          </div>

          {/* Qué documentos pedir */}
          <div style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:12,padding:"20px"}}>
            <div style={{fontSize:13,fontWeight:800,color:C.text,marginBottom:12}}>📋 Lista de documentos a pedir al cliente</div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
              {[["💰 Ingresos","Certificado de ingresos y retenciones (empleador), extractos honorarios o certificado de pensión"],["🏠 Patrimonio","Impuesto predial, escritura/avalúo de inmuebles, tarjeta de propiedad de vehículos"],["🏦 Financiero","Extractos bancarios a Dic 31, certificados de CDT o inversiones"],["🏥 Deducciones","Certificado medicina prepagada, certificado intereses crédito vivienda"],["💳 Pasivos","Extractos de deudas, saldos tarjetas de crédito a Dic 31"],["👨‍👩‍👧 Otros","Nombres y cédulas de dependientes económicos (hijos, padres, etc.)"]].map(([t,d])=>(
                <div key={t} style={{background:C.surface,borderRadius:8,padding:"12px 14px"}}>
                  <div style={{fontSize:12,fontWeight:800,color:C.text,marginBottom:4}}>{t}</div>
                  <div style={{fontSize:11,color:C.muted,lineHeight:1.5}}>{d}</div>
                </div>
              ))}
            </div>
          </div>
        </>
      )}

      {editando&&datos&&(
        <div>
          {datos.notas&&(
            <div style={{background:C.goldDim,border:`1px solid ${C.gold}33`,borderRadius:10,padding:"12px 16px",marginBottom:20,fontSize:12,color:C.gold}}>
              🤖 IA: {datos.notas}
            </div>
          )}
          <div style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:14,padding:"24px",marginBottom:16}}>
            <div style={{fontSize:14,fontWeight:800,color:C.text,marginBottom:18}}>✏️ Revisa y completa los datos extraídos</div>

            {/* Ingresos */}
            <div style={{marginBottom:20}}>
              <div style={{fontSize:12,fontWeight:800,color:C.accent,marginBottom:12,display:"flex",alignItems:"center",gap:8}}>💰 INGRESOS<div style={{flex:1,height:1,background:C.border,marginLeft:8}}/></div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"0 20px"}}>
                <Campo label="Ingresos laborales" value={d.ingresos_laborales||""} onChange={v=>upd("ingresos_laborales",v)} type="number" placeholder="0" prefix="$" hint="Certificado de ingresos y retenciones"/>
                <Campo label="Honorarios / independiente" value={d.honorarios||""} onChange={v=>upd("honorarios",v)} type="number" placeholder="0" prefix="$"/>
                <Campo label="Pensión" value={d.pension||""} onChange={v=>upd("pension",v)} type="number" placeholder="0" prefix="$"/>
                <Campo label="Dividendos" value={d.dividendos||""} onChange={v=>upd("dividendos",v)} type="number" placeholder="0" prefix="$"/>
                <div style={{gridColumn:"1/-1"}}>
                  <Campo label="Retenciones practicadas" value={d.retenciones||""} onChange={v=>upd("retenciones",v)} type="number" placeholder="0" prefix="$" hint="Total retenciones del año"/>
                </div>
              </div>
            </div>

            {/* Patrimonio */}
            <div style={{marginBottom:20}}>
              <div style={{fontSize:12,fontWeight:800,color:C.blue,marginBottom:12,display:"flex",alignItems:"center",gap:8}}>🏠 PATRIMONIO<div style={{flex:1,height:1,background:C.border,marginLeft:8}}/></div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"0 20px"}}>
                <Campo label="Inmuebles (avalúo catastral)" value={d.patrimonio_inmuebles||""} onChange={v=>upd("patrimonio_inmuebles",v)} type="number" placeholder="0" prefix="$"/>
                <Campo label="Vehículos" value={d.patrimonio_vehiculos||""} onChange={v=>upd("patrimonio_vehiculos",v)} type="number" placeholder="0" prefix="$"/>
                <Campo label="Saldo cuentas bancarias" value={d.saldo_bancario||""} onChange={v=>upd("saldo_bancario",v)} type="number" placeholder="0" prefix="$"/>
                <Campo label="CDT / Inversiones" value={d.cdt_inversiones||""} onChange={v=>upd("cdt_inversiones",v)} type="number" placeholder="0" prefix="$"/>
              </div>
            </div>

            {/* Deducciones y pasivos */}
            <div style={{marginBottom:20}}>
              <div style={{fontSize:12,fontWeight:800,color:C.purple,marginBottom:12,display:"flex",alignItems:"center",gap:8}}>🏥 DEDUCCIONES Y PASIVOS<div style={{flex:1,height:1,background:C.border,marginLeft:8}}/></div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"0 20px"}}>
                <Campo label="Medicina prepagada" value={d.medicina_prepagada||""} onChange={v=>upd("medicina_prepagada",v)} type="number" placeholder="0" prefix="$" hint="Art. 387 E.T."/>
                <Campo label="Intereses crédito vivienda" value={d.intereses_vivienda||""} onChange={v=>upd("intereses_vivienda",v)} type="number" placeholder="0" prefix="$" hint="Máx. 1.200 UVT"/>
                <Campo label="Dependientes económicos" value={d.dependientes||"0"} onChange={v=>upd("dependientes",v)} type="number" placeholder="0" hint="Número de personas"/>
                <Campo label="Deuda hipotecaria" value={d.deuda_hipoteca||""} onChange={v=>upd("deuda_hipoteca",v)} type="number" placeholder="0" prefix="$"/>
                <div style={{gridColumn:"1/-1"}}>
                  <Campo label="Otras deudas" value={d.otras_deudas||""} onChange={v=>upd("otras_deudas",v)} type="number" placeholder="0" prefix="$" hint="Tarjetas, préstamos — saldo a Dic 31"/>
                </div>
              </div>
            </div>

            {/* Resumen previo */}
            <div style={{background:C.surface,borderRadius:10,padding:"16px",marginBottom:20,display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:12}}>
              <div><div style={{fontSize:10,color:C.muted,fontWeight:700,textTransform:"uppercase",letterSpacing:1,marginBottom:4}}>Ingresos</div><div style={{fontSize:18,fontWeight:900,color:C.accent}}>${fmt(totalIng)}</div></div>
              <div><div style={{fontSize:10,color:C.muted,fontWeight:700,textTransform:"uppercase",letterSpacing:1,marginBottom:4}}>Impuesto</div><div style={{fontSize:18,fontWeight:900,color:C.gold}}>${fmt(impuesto)}</div></div>
              <div><div style={{fontSize:10,color:C.muted,fontWeight:700,textTransform:"uppercase",letterSpacing:1,marginBottom:4}}>Saldo</div><div style={{fontSize:18,fontWeight:900,color:saldo>0?C.danger:C.accent}}>{saldo>0?"-":"+"}${fmt(Math.abs(saldo))}</div></div>
            </div>

            <div style={{display:"flex",gap:12}}>
              <Btn variant="ghost" onClick={()=>setEditando(false)}>← Volver a fotos</Btn>
              <Btn variant="primary" onClick={()=>onGuardar(datos,fotos,"pendiente_revision")}>
                ✓ Enviar a revisión del contador
              </Btn>
            </div>
          </div>
        </div>
      )}
      <style>{`@keyframes p{0%,100%{opacity:.3}50%{opacity:1}}`}</style>
    </div>
  );
}

// ── VISTA CONTADOR: REVISIÓN ───────────────────────────────
function RevisionContador({cliente, onVolver, onAprobar, onDevolver}){
  const [comentario, setComentario] = useState(cliente.comentario_contador||"");
  const d = cliente.datos||{};
  const totalIng=[d.ingresos_laborales,d.honorarios,d.pension,d.dividendos,d.otros_ingresos].reduce((a,b)=>a+(parseInt(b)||0),0);
  const deducTotal=Math.min(parseInt(d.medicina_prepagada||0),16*UVT)+Math.min(parseInt(d.intereses_vivienda||0),1200*UVT)+Math.min(parseInt(d.dependientes||0)*32*UVT*12,totalIng*0.10);
  const baseGrav=Math.max(0,totalIng-deducTotal);
  const impuesto=calcImp(baseGrav);
  const retenciones=parseInt(d.retenciones||0);
  const saldo=impuesto-retenciones;
  const patBruto=[d.patrimonio_inmuebles,d.patrimonio_vehiculos,d.saldo_bancario,d.cdt_inversiones].reduce((a,b)=>a+(parseInt(b)||0),0);
  const pasivos=[d.deuda_hipoteca,d.otras_deudas].reduce((a,b)=>a+(parseInt(b)||0),0);
  const uvts=Math.round(baseGrav/UVT);
  const tarifa=uvts>1090?"39%":uvts>650?"33%":uvts>360?"28%":uvts>195?"19%":"0%";

  return(
    <div>
      {/* Header contador */}
      <div style={{display:"flex",alignItems:"center",gap:14,marginBottom:24}}>
        <button onClick={onVolver} style={{background:C.surface,border:`1px solid ${C.border}`,borderRadius:8,padding:"8px 14px",color:C.sub,cursor:"pointer",fontSize:13,fontWeight:700}}>← Volver</button>
        <div style={{flex:1}}>
          <div style={{fontSize:20,fontWeight:900,color:C.text}}>{cliente.nombre}</div>
          <div style={{fontSize:12,color:C.muted}}>C.C. {cliente.cedula} · {cliente.tipo} · Preparado por Asistente</div>
        </div>
        <Tag color={C.blue}>👁️ Pendiente revisión</Tag>
      </div>

      {!cliente.datos?(
        <div style={{textAlign:"center",padding:"60px 0",color:C.muted}}>
          <div style={{fontSize:40,marginBottom:12}}>📭</div>
          <div style={{fontSize:16,fontWeight:700,color:C.text,marginBottom:6}}>Sin datos para revisar</div>
          <div style={{fontSize:13}}>La asistente aún no ha procesado los documentos de este cliente.</div>
        </div>
      ):(
        <>
          {/* Resultado principal */}
          <div style={{background:saldo>0?C.dangerDim:C.accentDim,border:`2px solid ${saldo>0?C.danger:C.accent}44`,borderRadius:14,padding:"24px 28px",marginBottom:20,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
            <div>
              <div style={{fontSize:12,fontWeight:700,color:saldo>0?C.danger:C.accent,letterSpacing:1.5,textTransform:"uppercase",marginBottom:6}}>
                {saldo>0?"⚠️ Saldo a pagar":"✅ Saldo a favor"}
              </div>
              <div style={{fontSize:40,fontWeight:900,color:saldo>0?C.danger:C.accent,letterSpacing:"-2px"}}>${fmt(Math.abs(saldo))}</div>
              <div style={{fontSize:12,color:C.muted,marginTop:4}}>COP · Art. 241 E.T. · UVT 2024: $47.065</div>
            </div>
            <div style={{textAlign:"right"}}>
              <div style={{fontSize:12,color:C.muted,marginBottom:4}}>Tarifa marginal</div>
              <div style={{fontSize:32,fontWeight:900,color:C.gold}}>{tarifa}</div>
              <div style={{fontSize:11,color:C.muted}}>{uvts} UVT base gravable</div>
            </div>
          </div>

          {/* Grilla de datos */}
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:16,marginBottom:20}}>
            {/* Ingresos */}
            <div style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:12,padding:"18px"}}>
              <div style={{fontSize:12,fontWeight:800,color:C.accent,marginBottom:12}}>💰 INGRESOS</div>
              {[["Laborales",d.ingresos_laborales],["Honorarios",d.honorarios],["Pensión",d.pension],["Dividendos",d.dividendos],["Otros",d.otros_ingresos]].filter(([,v])=>parseInt(v)>0).map(([l,v])=>(
                <div key={l} style={{display:"flex",justifyContent:"space-between",padding:"7px 0",borderBottom:`1px solid ${C.border}22`,fontSize:13}}>
                  <span style={{color:C.sub}}>{l}</span><span style={{fontWeight:700,color:C.text}}>${fmt(v)}</span>
                </div>
              ))}
              <div style={{display:"flex",justifyContent:"space-between",padding:"10px 0 0",fontWeight:900,fontSize:14}}>
                <span style={{color:C.accent}}>Total ingresos</span><span style={{color:C.accent}}>${fmt(totalIng)}</span>
              </div>
            </div>

            {/* Liquidación */}
            <div style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:12,padding:"18px"}}>
              <div style={{fontSize:12,fontWeight:800,color:C.gold,marginBottom:12}}>🧾 LIQUIDACIÓN</div>
              {[["Ingresos brutos",fmt(totalIng),C.text],["(-) Deducciones",fmt(deducTotal),C.purple],["= Base gravable",fmt(baseGrav),C.text],["Impuesto liquidado",fmt(impuesto),C.gold],["(-) Retenciones",fmt(retenciones),C.blue]].map(([l,v,col])=>(
                <div key={l} style={{display:"flex",justifyContent:"space-between",padding:"7px 0",borderBottom:`1px solid ${C.border}22`,fontSize:13}}>
                  <span style={{color:C.sub}}>{l}</span><span style={{fontWeight:700,color:col}}>${v}</span>
                </div>
              ))}
              <div style={{display:"flex",justifyContent:"space-between",padding:"10px 0 0",fontWeight:900,fontSize:14}}>
                <span style={{color:saldo>0?C.danger:C.accent}}>{saldo>0?"Saldo a pagar":"Saldo a favor"}</span>
                <span style={{color:saldo>0?C.danger:C.accent}}>${fmt(Math.abs(saldo))}</span>
              </div>
            </div>

            {/* Patrimonio */}
            <div style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:12,padding:"18px"}}>
              <div style={{fontSize:12,fontWeight:800,color:C.blue,marginBottom:12}}>🏠 PATRIMONIO</div>
              {[["Inmuebles",d.patrimonio_inmuebles],["Vehículos",d.patrimonio_vehiculos],["Saldos bancarios",d.saldo_bancario],["CDT / Inversiones",d.cdt_inversiones]].filter(([,v])=>parseInt(v)>0).map(([l,v])=>(
                <div key={l} style={{display:"flex",justifyContent:"space-between",padding:"7px 0",borderBottom:`1px solid ${C.border}22`,fontSize:13}}>
                  <span style={{color:C.sub}}>{l}</span><span style={{fontWeight:700,color:C.text}}>${fmt(v)}</span>
                </div>
              ))}
              <div style={{display:"flex",justifyContent:"space-between",padding:"10px 0 0",fontWeight:800,fontSize:13}}>
                <span style={{color:C.blue}}>Patrimonio líquido</span><span style={{color:C.blue}}>${fmt(patBruto-pasivos)}</span>
              </div>
            </div>

            {/* Deducciones */}
            <div style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:12,padding:"18px"}}>
              <div style={{fontSize:12,fontWeight:800,color:C.purple,marginBottom:12}}>🏥 DEDUCCIONES APLICADAS</div>
              {[["Med. prepagada (máx. 16 UVT)",Math.min(parseInt(d.medicina_prepagada||0),16*UVT)],["Intereses vivienda (máx. 1.200 UVT)",Math.min(parseInt(d.intereses_vivienda||0),1200*UVT)],["Dependientes (máx. 10% ing.)",Math.min(parseInt(d.dependientes||0)*32*UVT*12,totalIng*0.10)]].filter(([,v])=>v>0).map(([l,v])=>(
                <div key={l} style={{display:"flex",justifyContent:"space-between",padding:"7px 0",borderBottom:`1px solid ${C.border}22`,fontSize:12}}>
                  <span style={{color:C.sub}}>{l}</span><span style={{fontWeight:700,color:C.purple}}>-${fmt(v)}</span>
                </div>
              ))}
              <div style={{display:"flex",justifyContent:"space-between",padding:"10px 0 0",fontWeight:900,fontSize:13}}>
                <span style={{color:C.purple}}>Total deducciones</span><span style={{color:C.purple}}>-${fmt(deducTotal)}</span>
              </div>
            </div>
          </div>

          {/* Normas */}
          <div style={{background:C.goldDim,border:`1px solid ${C.gold}22`,borderRadius:9,padding:"12px 16px",marginBottom:20,fontSize:11,color:C.sub,lineHeight:1.8}}>
            <strong style={{color:C.gold}}>📚 Normas:</strong> Art. 241 E.T. (tabla) · Art. 387 E.T. (deducciones) · Art. 119 E.T. (intereses vivienda) · Art. 367 E.T. (retenciones) · Res. 000187/2023 UVT $47.065
          </div>

          {/* Comentario y acciones */}
          <div style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:12,padding:"20px",marginBottom:16}}>
            <div style={{fontSize:13,fontWeight:800,color:C.text,marginBottom:10}}>💬 Comentario (opcional)</div>
            <textarea value={comentario} onChange={e=>setComentario(e.target.value)} placeholder="Ej: Revisar certificado de ingresos, falta firma del empleador..."
              style={{width:"100%",padding:"10px 12px",background:C.surface,border:`1px solid ${C.border}`,borderRadius:8,color:C.text,fontSize:13,resize:"vertical",minHeight:80,outline:"none",boxSizing:"border-box",fontFamily:"inherit"}}
              onFocus={e=>e.target.style.borderColor=C.accent} onBlur={e=>e.target.style.borderColor=C.border}/>
            <div style={{display:"flex",gap:12,marginTop:16,justifyContent:"flex-end"}}>
              <Btn variant="danger" onClick={()=>onDevolver(comentario)}>↩️ Devolver a asistente</Btn>
              <Btn variant="primary" size="lg" onClick={()=>onAprobar(comentario)}>✅ Dar visto bueno</Btn>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

// ── DASHBOARD ──────────────────────────────────────────────
function Dashboard({clientes, rol, onAbrir}){
  const counts=Object.keys(STATUS).reduce((a,k)=>({...a,[k]:clientes.filter(c=>c.estado===k).length}),{});
  const pendientes=clientes.filter(c=>c.estado==="pendiente_revision");

  return(
    <div>
      <div style={{marginBottom:28}}>
        <div style={{fontSize:26,fontWeight:900,color:C.text,marginBottom:4}}>
          {rol==="asistente"?"👋 Hola, Asistente":"👨‍💼 Hola, Contador"}
        </div>
        <div style={{fontSize:13,color:C.muted}}>
          {rol==="asistente"?"Organiza los documentos y prepara las declaraciones para revisión.":"Revisa las declaraciones preparadas y da el visto bueno."}
        </div>
      </div>

      {/* Stats */}
      <div style={{display:"grid",gridTemplateColumns:"repeat(5,1fr)",gap:12,marginBottom:28}}>
        {Object.entries(STATUS).map(([k,st])=>(
          <div key={k} style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:11,padding:"14px 16px",borderLeft:`3px solid ${st.color}`}}>
            <div style={{fontSize:10,fontWeight:700,color:C.muted,textTransform:"uppercase",letterSpacing:1,marginBottom:6}}>{st.label}</div>
            <div style={{fontSize:26,fontWeight:900,color:st.color}}>{counts[k]||0}</div>
          </div>
        ))}
      </div>

      {/* Alerta pendientes para contador */}
      {rol==="contador"&&pendientes.length>0&&(
        <div style={{background:C.blueDim,border:`1px solid ${C.blue}44`,borderRadius:12,padding:"16px 20px",marginBottom:24,display:"flex",alignItems:"center",justifyContent:"space-between"}}>
          <div>
            <div style={{fontSize:14,fontWeight:800,color:C.blue,marginBottom:3}}>👁️ {pendientes.length} declaración{pendientes.length>1?"es":""} esperando tu revisión</div>
            <div style={{fontSize:12,color:C.muted}}>{pendientes.map(c=>c.nombre.split(" ")[0]).join(", ")}</div>
          </div>
          <Btn variant="blue" onClick={()=>onAbrir(pendientes[0])}>Revisar ahora →</Btn>
        </div>
      )}

      {/* Lista de clientes */}
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16}}>
        <div style={{fontSize:15,fontWeight:800,color:C.text}}>Clientes · AG 2024</div>
        {rol==="asistente"&&<Btn variant="primary" size="sm">+ Nuevo cliente</Btn>}
      </div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14}}>
        {clientes.map(c=><TarjetaCliente key={c.id} c={c} onAbrir={onAbrir} rol={rol}/>)}
      </div>
    </div>
  );
}

// ── APP PRINCIPAL ──────────────────────────────────────────
export default function App(){
  const [rol, setRol] = useState(null);
  const [clientes, setClientes] = useState(CLIENTES_DEMO);
  const [clienteActivo, setClienteActivo] = useState(null);
  const [vista, setVista] = useState("dashboard"); // dashboard | detalle

  const abrirCliente = c=>{ setClienteActivo(c); setVista("detalle"); };
  const volver = ()=>{ setVista("dashboard"); setClienteActivo(null); };

  const guardarDatos = (datos, fotos, nuevoEstado)=>{
    setClientes(p=>p.map(c=>c.id===clienteActivo.id?{...c,datos,docs:fotos.map(f=>f.name),estado:nuevoEstado,fecha:now()}:c));
    volver();
  };

  const aprobar = (comentario)=>{
    setClientes(p=>p.map(c=>c.id===clienteActivo.id?{...c,estado:"aprobado",comentario_contador:comentario,fecha:now()}:c));
    volver();
  };

  const devolver = (comentario)=>{
    setClientes(p=>p.map(c=>c.id===clienteActivo.id?{...c,estado:"en_proceso",comentario_contador:comentario,fecha:now()}:c));
    volver();
  };

  // Pantalla de selección de rol
  if(!rol){
    return(
      <div style={{minHeight:"100vh",background:C.bg,fontFamily:"'DM Sans','Segoe UI',sans-serif",color:C.text,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:24}}>
        <div style={{position:"fixed",inset:0,background:`radial-gradient(ellipse 60% 40% at 50% 20%, ${C.accentGlow}, transparent)`,pointerEvents:"none"}}/>
        <div style={{fontSize:48,marginBottom:16}}>🇨🇴</div>
        <div style={{fontSize:32,fontWeight:900,color:C.text,marginBottom:6,letterSpacing:"-1px"}}>Tributario<span style={{color:C.accent}}>CO</span></div>
        <div style={{fontSize:14,color:C.muted,marginBottom:48,letterSpacing:1}}>SISTEMA INTERNO DE DECLARACIONES · AG 2024</div>

        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:20,maxWidth:520,width:"100%"}}>
          {[
            {r:"asistente",icon:"👩‍💻",titulo:"Soy la Asistente",desc:"Recibo documentos, subo fotos y organizo las declaraciones para revisión",color:C.accent},
            {r:"contador",icon:"👨‍💼",titulo:"Soy el Contador",desc:"Reviso las declaraciones preparadas y doy el visto bueno final",color:C.blue},
          ].map(x=>(
            <div key={x.r} onClick={()=>setRol(x.r)}
              style={{background:C.card,border:`1.5px solid ${C.border}`,borderRadius:16,padding:"28px 24px",cursor:"pointer",textAlign:"center",transition:"all 0.2s"}}
              onMouseEnter={e=>{e.currentTarget.style.borderColor=x.color;e.currentTarget.style.background=x.color+"10";}}
              onMouseLeave={e=>{e.currentTarget.style.borderColor=C.border;e.currentTarget.style.background=C.card;}}>
              <div style={{fontSize:44,marginBottom:12}}>{x.icon}</div>
              <div style={{fontSize:16,fontWeight:900,color:C.text,marginBottom:8}}>{x.titulo}</div>
              <div style={{fontSize:12,color:C.muted,lineHeight:1.6}}>{x.desc}</div>
              <div style={{marginTop:16,padding:"8px 20px",borderRadius:8,background:x.color+"18",color:x.color,fontSize:12,fontWeight:700,display:"inline-block"}}>Entrar →</div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return(
    <div style={{minHeight:"100vh",background:C.bg,fontFamily:"'DM Sans','Segoe UI',sans-serif",color:C.text}}>
      {/* Header */}
      <div style={{borderBottom:`1px solid ${C.border}`,padding:"0 32px",background:C.surface,position:"sticky",top:0,zIndex:100}}>
        <div style={{maxWidth:1000,margin:"0 auto",display:"flex",alignItems:"center",justifyContent:"space-between",height:58}}>
          <div style={{display:"flex",alignItems:"center",gap:14}}>
            <div style={{fontSize:17,fontWeight:900,color:C.text}}>Tributario<span style={{color:C.accent}}>CO</span></div>
            <div style={{width:1,height:18,background:C.border}}/>
            <Tag color={rol==="asistente"?C.accent:C.blue}>{rol==="asistente"?"👩‍💻 Asistente":"👨‍💼 Contador"}</Tag>
          </div>
          <div style={{display:"flex",alignItems:"center",gap:10}}>
            <span style={{fontSize:12,color:C.muted}}>
              {clientes.filter(c=>c.estado==="pendiente_revision").length>0&&rol==="contador"&&
                <span style={{color:C.blue,fontWeight:700}}>⚡ {clientes.filter(c=>c.estado==="pendiente_revision").length} pendiente(s)</span>}
            </span>
            <button onClick={()=>setRol(null)} style={{background:"transparent",border:`1px solid ${C.border}`,borderRadius:7,padding:"6px 14px",color:C.sub,cursor:"pointer",fontSize:12,fontWeight:700}}>Cambiar rol</button>
          </div>
        </div>
      </div>

      {/* Contenido */}
      <div style={{maxWidth:1000,margin:"0 auto",padding:"32px 32px 80px"}}>
        {vista==="dashboard"&&<Dashboard clientes={clientes} rol={rol} onAbrir={abrirCliente}/>}
        {vista==="detalle"&&clienteActivo&&rol==="asistente"&&(
          <SubirDocs cliente={clienteActivo} onVolver={volver} onGuardar={guardarDatos}/>
        )}
        {vista==="detalle"&&clienteActivo&&rol==="contador"&&(
          <RevisionContador cliente={clienteActivo} onVolver={volver} onAprobar={aprobar} onDevolver={devolver}/>
        )}
      </div>
      <style>{`*{box-sizing:border-box;margin:0;padding:0} input[type=number]::-webkit-inner-spin-button{-webkit-appearance:none} textarea{font-family:inherit}`}</style>
    </div>
  );
}
