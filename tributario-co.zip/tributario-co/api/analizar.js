// api/analizar.js — Vercel Serverless Function
// La API key vive aquí en el servidor, NUNCA en el navegador

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Método no permitido' })
  }

  const apiKey = process.env.ANTHROPIC_API_KEY
  if (!apiKey) {
    return res.status(500).json({ error: 'API key no configurada' })
  }

  try {
    const { messages } = req.body

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1024,
        messages,
      }),
    })

    if (!response.ok) {
      const err = await response.text()
      console.error('Error Anthropic:', err)
      return res.status(response.status).json({ error: 'Error en Claude API' })
    }

    const data = await response.json()
    return res.status(200).json(data)

  } catch (error) {
    console.error('Error función:', error)
    return res.status(500).json({ error: 'Error interno' })
  }
}
